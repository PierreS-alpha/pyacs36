#!/usr/bin/env python

###################################################################
# SCRIPT    : pygeca_sinex_2_apr.py
# AUTHOR    : JM NOCQUET
# DATE      : June 2011
# INPUT     : sinex files
# OUTPUT    : Globk compatible apr file 
# NOTE      :
#         
###################################################################

###################################################################
# MODULES IMPORT
###################################################################

import getopt, sys

#from pyacs.sol import gpoint as Gpoint
from pyacs.sol import sinex as Sinex
from pyacs.lib.astrotime import *
#from pyacs.lib import coordinates as  Coordinates


###################################################################
# PARSE ARGUMENT LINE
###################################################################

def get_arg():
    #print sys.argv 
    try:
        opts, args = getopt.getopt(sys.argv[1:], "vhl:r:a:", ["help", "output="])
        #print opts
    except getopt.GetoptError as err:
        # print help information and exit:
        print(str(err)) # will print something like "option -a not recognized"
        usage()
        sys.exit(2)
    if not opts:
        usage()
        sys.exit()
    output = None
    verbose = False
    for o, a in opts:
        #print "%s %s" % (o,a)
        if o == "-v":
            verbose = True
        elif o in ("-h", "--help"):
            usage()
            sys.exit()
        elif o in ("-r"):
            ref_sinex_name = a           
        elif o in ("-a"):
            apr_file = a           
    return (ref_sinex_name,apr_file)

###################################################################
# USAGE
###################################################################

def usage():
    print("=> pygeca_sinex_2_apr.py -r [sinex file] -a [apr file] -h -v")
    sys.exit()
    
###################################################################
# GETS ARGUMENT LINE
###################################################################

(ref_sinex_name,apr_file)=get_arg()


###################################################################
# READS REFERENCE SINEX FILE
###################################################################


print('=> Reading reference SINEX file ',ref_sinex_name)
ref_sinex=Sinex.SSinex(ref_sinex_name)
#print 'exclude ',conf.ref_exclude_all
ref_sinex.read_section_estimate()
print('=> OK reference SINEX file ',ref_sinex.name)

###################################################################
# WRITES THE APR FILE
###################################################################

f1=open(apr_file,'w')


for point in ref_sinex.estimates:
    (xr,yr,zr)=point.posxyz()
    (vxr,vyr,vzr)=point.velxyz()
    if (vxr,vyr,vzr)==(None,None,None): (vxr,vyr,vzr)=(0.,0.,0.) 
    (sxr,syr,szr)=(point.SX,point.SY,point.SZ)
    (svxr,svyr,svzr)=(point.SVX,point.SVY,point.SVZ)
    if (svxr,svyr,svzr)==(None,None,None): (svxr,svyr,svzr)=(0.,0.,0.) 
    
    epoch=point.epoch
    if point.soln==1:
        soln_globk='GP'
    else:
        soln_globk=("%02d" % int(point.soln))
    #print point.epoch
    #(lam,phi,h)=Coordinates.xyz2geo(x, y, z)
    f1.write(" %s_%sS %14.5lf %14.5lf %14.5lf %10.5lf %10.5lf %10.5lf %8.3lf %7.4lf %7.4lf %7.4lf  %7.5lf %7.5lf %7.5lf\n" %(point.code,soln_globk,xr,yr,zr,vxr,vyr,vzr,point.epoch,sxr,syr,szr,svxr,svyr,svzr))


f1.close()