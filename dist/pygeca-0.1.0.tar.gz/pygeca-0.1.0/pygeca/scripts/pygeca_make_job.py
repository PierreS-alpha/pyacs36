#!/usr/bin/env python

"""Automated GAMIT processing using the cluster at Geoazur
   Jean-Mathieu Nocquet - April 2012 - Updated from geca in perl
   pygeca_make_job.py
   Report bug to nocquet@geoazur.unice.fr
"""
###################################################################
# MODULES IMPORT
###################################################################


import sys, os, stat
import argparse

from pyacs.lib import astrotime as AstroTime



###################################################################
# PARSE ARGUMENT LINE
###################################################################

parser = argparse.ArgumentParser()
parser.add_argument('--dir_conf', action='store', type=str, dest='dir_conf',help='directory including configuration files')
parser.add_argument('--sd', action='store', type=int, dest='start_doy',help='starting doy')
parser.add_argument('--ed', action='store', type=int, dest='end_doy',help='end doy')
parser.add_argument('--ld', action='append', type=int, dest='list_doy',help='list of doy to be processed', default=[])
parser.add_argument('--year', action='store', type=int, dest='year',help='year')
parser.add_argument('--type', action='store', type=str, dest='type_analysis',help='best|precise|rapid', default='best')
parser.add_argument('--experiment', action='store', type=str, dest='expt',help='experiment name')
parser.add_argument('--queue', action='store', type=str, dest='queue',help='queue [QDR/DDR/NONE]')
parser.add_argument('--walltime', action='store', type=int, dest='walltime',default=6,help='expected job duration (integer in hours), default=6')
parser.add_argument('--x', action='append', type=str, dest='lexclude_site',help='list of sites to be excluded from processing', default=[])

if (len(sys.argv)<2):parser.print_help()
    
args = parser.parse_args()

if not (args.year and args.expt and args.dir_conf and args.queue):
    parser.print_help()
    sys.exit()
if not ((args.start_doy and args.end_doy) or args.list_doy):
    parser.print_help()
    sys.exit()
if args.start_doy and args.end_doy:
    smjd=AstroTime.dayno2mjd(args.start_doy, args.year, ut=0.0)
    emjd=AstroTime.dayno2mjd(args.end_doy, args.year, ut=0.0)
    for mjd in range(int(smjd),int(emjd)+1):
        (doy,year,ut)=AstroTime.mjd2dayno(mjd)
        args.list_doy.append(doy)

###################################################################
# CHECK CONFIGURATION DIRECTORY
###################################################################

if not os.path.exists(args.dir_conf):
    print("=> ",args.dir_conf, " directory does not exist. Exiting...")
    sys.exit()
    
# String for the queue

str_queue='#OAR -p '
if 'none' in args.queue.lower():str_queue+= "ib=\'none\'"
if 'DDR' in args.queue.upper():
    if 'none' in str_queue:
        str_queue+= " OR ib=\'DDR\'"
    else:
        str_queue+= "ib=\'DDR\'"

if 'QDR' in args.queue.upper():
    if 'none' in str_queue or 'DDR' in str_queue:
        str_queue+= " OR ib=\'QDR\'"
    else:
        str_queue+= "ib=\'QDR\'"
        



###################################################################
# LOOP ON LDOY
###################################################################

for doy in args.list_doy:
    sdoy= "%03d" % doy
    syear=str(args.year)

    print("=> Processing doy:",sdoy," year:",syear)
    

    ###################################################################
    # CREATES PROCESSING DIRECTORY
    ###################################################################
    
    
    current_dir=os.environ['PWD']
    
    job=args.expt+'_'+sdoy+'_'+syear
    fs=open(job,'w')
    
    fs.write('#!/bin/bash\n') 
    fs.write('./user/'+os.environ['USER']+'/.bashrc\n')
    fs.write("#OAR -l core=1,walltime=%02d:00:0\n" % (args.walltime))
    fs.write("#OAR -n %s\n" % job)
    fs.write('#OAR -O %jobid%.out\n')
    fs.write("%s\n" % str_queue)

    fs.write('cd /tmp\n')
    wdir= "%s_%s_%s_%s" % (os.environ['USER'],args.expt,args.year,sdoy)
    if args.lexclude_site == []:
        str_exclude_site=''
    else:
        str_exclude_site=' --x ' + ' --x '.join(args.lexclude_site)
    fs.write("pygeca_subnetworks.py  --dir_conf %s --sd %s --ed %s --year %s --type %s --experiment %s %s > log.pygeca.%s_%s_%s\n" % (args.dir_conf,sdoy,sdoy,args.year,args.type_analysis,args.expt,str_exclude_site, args.expt,sdoy,args.year))
    fs.write("mv -f %s %s/.\n" % (wdir,current_dir))
    fs.close()
    os.chmod(job, stat.S_IRWXU)

    
    
