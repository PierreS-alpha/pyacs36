#!/usr/bin/env python

"""Automated GAMIT processing using the cluster at Geoazur
   Preforms a check before running a solution on the cluster
   The check are:
   - check gamit configuration
   - missing sp3 and brdc
   - missing data for the time pan
   - missing site sites.defaults
   - missing apr information in the apr
   - missing info in station.info
   
   Jean-Mathieu Nocquet - April 2012 - Updated from geca in perl
   Report bug to nocquet@geoazur.unice.fr
"""
###################################################################
# MODULES IMPORT
###################################################################


import sys, os
import argparse
from glob import glob

from pyacs.lib import astrotime as AstroTime
from pyacs.lib import gpstime as GpsTime

###################################################################
# PARSE ARGUMENT LINE
###################################################################

parser = argparse.ArgumentParser()
parser.add_argument('-dir_conf', required=True,action='store', type=str, dest='dir_conf',help='directory including configuration files')
parser.add_argument('-sd', action='store', type=int, dest='start_doy',help='starting doy')
parser.add_argument('-ed', action='store', type=int, dest='end_doy',help='end doy')
parser.add_argument('-ld', action='append', type=int, dest='list_doy',help='list of doy to be processed', default=[])
parser.add_argument('-year', required=True,action='store', type=int, dest='year',help='year')
parser.add_argument('--experiment', action='store', type=str, dest='expt',help='experiment name',default=None)
parser.add_argument('--missing', action='count',default=0,help='warns for missing data (useful for cgps)')
parser.add_argument('--small', action='count',default=0,help='warns for small rinex files')


if (len(sys.argv)<2):parser.print_help()
    
args = parser.parse_args()

# missing
if args.missing>0:
    missing=True
else:
    missing=False

# small
if args.small>0:
    small=True
else:
    small=False

if not (args.year and args.expt and args.dir_conf):
    parser.print_help()
    sys.exit()
if not ((args.start_doy and args.end_doy) or args.list_doy):
    parser.print_help()
    sys.exit()
if args.start_doy and args.end_doy:
    smjd=AstroTime.dayno2mjd(args.start_doy, args.year, ut=0.0)
    emjd=AstroTime.dayno2mjd(args.end_doy, args.year, ut=0.0)
    for mjd in range(int(smjd),int(emjd)+1):
        (doy,year,ut)=AstroTime.mjd2dayno(mjd)
        args.list_doy.append(doy)

syear=str(args.year)

###################################################################
# CHECKING GAMIT CONFIGURATION
###################################################################

print("=> Checking GAMIT configuration")

gamit_path=os.environ['GAMIT']
if not os.path.exists(gamit_path):
    print("=> ",gamit_path, " directory does not exist. Check your GAMIT configuration in .bashrc. Exiting...")
    sys.exit()
else:
    gamit_tables_path=gamit_path+'/tables'
    print("=> GAMIT tables to be found in ", gamit_tables_path)

grd_path=gamit_path+'/../grids'
if not os.path.exists(grd_path):
    print("=> ERROR:",grd_path, " directory does not exist.")

brdc_path=os.environ['BRDC']
if not os.path.exists(grd_path):
    print("=> ERROR:",brdc_path, " directory does not exist.")

sp3_path=os.environ['ORBIT']
if not os.path.exists(sp3_path):
    print("=> ERROR:",sp3_path, " sp3 orbit directory does not exist.")

min_rinex_size=100 # minimum size (Kb) for a rinex file to be processed


###################################################################
# CHECK GAMIT TABLES
###################################################################
    
import shutil
    
lgamit_tables=('autcln.cmd','sittbl.','rcvant.dat','leap.sec','antmod.dat','svnav.dat','hi.dat','svs_exclude.dat','gdetic.dat','eq_rename','dcb.dat','otlcmc.dat','sestbl.','station.info')
    
for table in lgamit_tables:
    path_table=args.dir_conf+'/'+table
    if not os.path.exists(path_table):path_table=gamit_tables_path+'/'+table

    if not os.path.exists(path_table):
        print("=> ERROR:",path_table, " not found")
# nutbl.
if not os.path.exists(gamit_tables_path+'/nutabl.'+syear):print("=> ERROR:",gamit_tables_path+'/nutabl.'+syear, " not found.")
# soltab
if not os.path.exists(gamit_tables_path+'/soltab.'+syear+'.J2000'):print("=> ERROR:",gamit_tables_path+'/soltab.'+syear+'.J2000', " not found.")
# luntab
if not os.path.exists(gamit_tables_path+'/luntab.'+syear+'.J2000'):print("=> ERROR:",gamit_tables_path+'/luntab.'+syear+'.J2000', " not found.")
# ut1
if not os.path.exists(gamit_tables_path+'/ut1.usno'):print("=> ERROR:",gamit_tables_path+'/ut1.usno', " not found.")
# pole
if not os.path.exists(gamit_tables_path+'/pole.usno'):print("=> ERROR:",gamit_tables_path+'/pole.usno', " not found.")


###################################################################
# LOADING GRIDS
###################################################################
try:
    atmlgrd=glob(grd_path+'/atmfilt_cm.'+syear+'*')[-1]
    print("=> atml grid ",atmlgrd)
except:
    print("=> ERROR: atml grid missing in ",grd_path)

try:
    vmf1grd=glob(grd_path+'/vmf1grd.'+syear+'*')[-1]
    print("=> vmf1 grid ",vmf1grd)
except:
    print("=> ERROR: vmf1 grid missing in ",grd_path)

    
lgamit_grid=('atl.grid','otl.grid')
for grid in lgamit_grid:
    if not os.path.exists(grd_path+'/'+grid):print("=> ERROR: ",grd_path+'/'+grid, "missing.")


###################################################################
# CHECK EXPERIMENT CONFIGURATION DIRECTORY
###################################################################

print(("=> Checking experiment %s directory %s" % (args.expt, args.dir_conf)))

if not os.path.exists(args.dir_conf):
    print(("=> ERROR: directory %s does not exist. Exiting..." % args.dir_conf))
    
lconf_files=('station.info','sestbl.','process.defaults')
for conf_file in (lconf_files):
    path_conf_file=args.dir_conf+'/'+conf_file
    if not os.path.exists(path_conf_file):
        print("=> ERROR: ",path_conf_file, " missing.")
print ("=> Experiment configuration files OK.")

###################################################################
# CHECK MISSING SP3
###################################################################

print("=> Checking availability of sp3 and brdc files")

lmissing_sp3=[]
lmissing_sp3r=[]
lmissing_brdc=[]

syr=syear[-2:]
for doy in args.list_doy:
    (day,month)=AstroTime.dayno2cal(doy,year)
    (gpsWeek, gpsSOW, gpsDay, gpsSOD)=GpsTime.gpsFromUTC(year, month, day, 0, 0, 0, leapSecs=30)
    gweek="%04d" % gpsWeek + str(gpsDay)
    sdoy="%03d" % doy
    nav_file = 'brdc'+ sdoy +'0.'+ syr +'n'
    sp3_file = 'igs'+gweek+'.sp3'
    sp3r_file = 'igr'+gweek+'.sp3'
    if not os.path.exists(brdc_path +'/'+nav_file):lmissing_brdc.append(doy)
    if not os.path.exists(sp3_path +'/'+sp3_file):lmissing_sp3.append(doy)
    if not os.path.exists(sp3_path +'/'+sp3r_file):lmissing_sp3r.append(doy)

if len(lmissing_sp3)==0:
    print("=> sp3 orbits OK.")
else:
    print("=> WARNING: missing sp3 files: %03d -> %03d\n" % (lmissing_sp3[0],lmissing_sp3[-1]))
    
if len(lmissing_sp3r)==0:
    print("=> Rapid sp3 orbits OK.")
else:
    print("=> WARNING: missing rapid sp3 files: %03d -> %03d\n" % (lmissing_sp3r[0],lmissing_sp3r[-1]))

if len(lmissing_brdc)==0:
    print("=> brdc orbits OK.")
else:
    print("=> ERROR: missing brdc files: %03d -> %03d\n" % (lmissing_brdc[0],lmissing_brdc[-1]))


###################################################################
# READS SITE.DEFAULTS
###################################################################

print("=> Reading sites.defaults file")

lsite=[]

   
site_defaults=args.dir_conf+'/sites.defaults'
fs=open(site_defaults,'r',encoding="latin-1")
for line in fs:
    if line[0]=='#' or len(line) < 3 or line[1]==' ':continue
    lline=line.split()
    if '_gps' in lline[0]:
        if args.expt:
            if args.expt in lline[1]:lsite.append(lline[0][0:4].lower())
        else:
            lsite.append(lline[0][0:4].lower())
fs.close()
    
print("=> sites.defaults OK.")


###################################################################
# READS process.defaults
###################################################################

    # Get the directories from process.defaults
    
process_defaults=args.dir_conf+'/process.defaults'


ldir_rinex=[]
fs=open(process_defaults,'r',encoding="latin-1")
for line in fs:
    if (line[0]!='#') and (len(line.replace(' ',''))) > 3:
        lline=line.split()
        if 'rnxfnd' in lline[1]:
            ldir_rinex.append(lline[-1].replace('"',''))
            print('-- adding rinex dir ',lline[-1].replace('"',''))
        if 'aprf' in lline[1]:aprf=args.dir_conf+'/'+lline[-1]
fs.close()

###################################################################
# READS APR files
###################################################################

print("=> Reading apr file", aprf)

lapr=[]

fapr=open(aprf,'r',encoding="latin-1")
for line in fapr:
    if (len(line)<5 or line[0]!=' '):continue
    lline=line.split()
    (site,X,Y,Z)=lline[0:4]
    lapr.append(site.lower()[0:4])
fapr.close()

print("=> apr file OK.")

###################################################################
# READS AVAILABLE RINEX
###################################################################

H_rinex={}
lrinex_all=[]

for doy in args.list_doy:
    syear=str(year)
    syr=syear[-2:]
    sdoy="%03d" % doy

    log_suffix=args.expt+'_'+syear+'_'+sdoy

    print("=> Reading rinex files for doy:",sdoy," year:",syear)
    

    if not os.path.exists(aprf):print("ERROR: apr file read in process.defaults not found :",aprf)
    
    # list the rinex files
    lrinex=[]
    for rinex_dir in ldir_rinex:
        lrinex+=glob(rinex_dir+'/'+syear+'/'+sdoy+'/*')
        lrinex_all+=glob(rinex_dir+'/'+syear+'/'+sdoy+'/*')

    
    # link the rinex files if site code is in sites.defaults
    
    nrinex=0
    
    for rinex in lrinex:
        rinex_basename=rinex.split('/')[-1]
        site_rinex=rinex_basename[0:4].lower()
        doy_rinex=rinex_basename[4:7]
        if site_rinex in H_rinex:
            H_rinex[site_rinex].append(doy_rinex)
        else:
            H_rinex[site_rinex]=[doy_rinex]
        #print os.path.getsize(rinex),min_rinex_size
        if small:
            if os.path.getsize(rinex)/1024. <min_rinex_size:print("=> WARNING: small rinex file ",rinex)

print("=> End of rinex listing.")
print("=> Found ",len(lrinex_all)," rinex files")

#for line in lrinex_all:
#    print line

###################################################################
# WARNS ABOUT MISSING DATA
###################################################################

if missing:
    print("=> Checking for missing data")
    
    for site in sorted(H_rinex.keys()):
        str_missing_doy=''
        for doy in args.list_doy:
            sdoy="%03d" % doy
            if sdoy not in H_rinex[site]:str_missing_doy+=sdoy+' '
        if len(str_missing_doy)>2: print(("=> WARNING missing doys for %s: %s" % (site,str_missing_doy)))

###################################################################
# CHECKING SITES.DEFAULTS CONTENT
###################################################################

print("=> Checking sites.defaults file vs rinex")

for site in sorted(H_rinex.keys()):
    if site not in lsite: print(("=> WARNING site %s not in sites.defaults" % (site)))
    
###################################################################
# ERROR ABOUT MISSING SITES in apr file
###################################################################

print("=> Checking rinex list vs apr file ",aprf)

#print lapr

for site in sorted(H_rinex.keys()):
    if site not in lapr:
        #print lrinex        

        print("  -- Looking for rinex for site ",site)
        try:
            rinex1=[x for x in lrinex_all if site in x][0]
            print(("=> rinex %s"%rinex1))
 
        except:
            print('  -- !!! Could not find rinex for site ',site)
        
        if site in lsite:
            print(("=> ERROR: site %s not in aprf file %s" % (site, aprf)))
        else:
            print(("=> WARNING: if to be processed, site %s not in aprf file %s" % (site, aprf)))
            
###################################################################
# CHECK STATION INFO FILE
###################################################################

station_info=args.dir_conf+'/station.info'
print("=> Checking station.info ",station_info)

H_station_info={}



# Reads station info file

site_previous=''
smjd_site=AstroTime.dayno2mjd(1,2100, ut=0.0)
emjd_site=AstroTime.dayno2mjd(1, 1980, ut=0.0)

#print smjd_site,emjd_site

buffer=False

fstnfo=open(station_info,'r',encoding="latin-1")
for line in fstnfo:
    #print line
    if (len(line)<5 or line[0]!=' '):continue
    lline=line.split()
    site=lline[0].lower()
    reste=line[25:].split()
    if site != site_previous and buffer:
        #print 'writting info for ',site_previous
        H_station_info[site_previous]=(smjd_site,emjd_site)
        #print H_station_info
        site_previous=site
        smjd_site=AstroTime.dayno2mjd(1,2100, ut=0.0)
        emjd_site=AstroTime.dayno2mjd(1, 1980, ut=0.0)
        buffer=False

    if site not in list(H_rinex.keys()):continue
    
    
    buffer=True
    #print 'site ',site    
    #print line
    (syear,sdoy)=list(map(int,(reste[0],reste[1])))
    (eyear,edoy)=list(map(int,(reste[5],reste[6])))

    if syear==0:syear=1980
    if syear==9999:syear=2100
    if sdoy==0:sdoy=1
    if sdoy==999:sdoy=365
    
    if eyear==0:eyear=1980
    if eyear==9999:eyear=2100
    if edoy==0:edoy=1
    if edoy==999:edoy=365

    #print (syear,sdoy)
    #print (eyear,edoy)
    ssmjd_site=AstroTime.dayno2mjd(sdoy, syear, ut=0.0)
    if ssmjd_site<smjd_site:smjd_site=ssmjd_site
    
    esmjd_site=AstroTime.dayno2mjd(edoy, eyear, ut=0.0)
    if esmjd_site>emjd_site:emjd_site=esmjd_site
    site_previous=site
    
fstnfo.close()
if site in list(H_rinex.keys()):H_station_info[site]=(smjd_site,emjd_site)

# Now check station.info is OK

#print H_station_info

for site in sorted(H_rinex.keys()):
    for str_doy in H_rinex[site]:
        if site not in H_station_info:

            print("  -- Looking for rinex for site ",site)
            try:
                rinex1=[x for x in lrinex_all if site in x][0]
                print(("=> rinex %s"%rinex1))
            except:
                print('  -- !!! Could not find rinex for site ',site)


            if site in lsite:
                print(("=> ERROR: missing info for site : %s in %s/station.info" % (site,args.dir_conf)))
                break
            else:
                print(("=> WARNING: missing info for site : %s in %s/station.info (but %s is not in sites.defaults and will not be processed)" % (site,args.dir_conf,site)))
                break
        doy=int(str_doy)
        mjd=AstroTime.dayno2mjd(doy,year)
        #print doy,year,mjd
        #print H_station_info[site]
        if site in lsite:
            if mjd < H_station_info[site][0] or mjd > H_station_info[site][-1]: 
                print(("=> ERROR: check station.info for site %s doy: %s " % (site,str_doy)))
                rinex1=[x for x in lrinex_all if site in x][0]
                print(("=> rinex %s"%rinex1))

 
