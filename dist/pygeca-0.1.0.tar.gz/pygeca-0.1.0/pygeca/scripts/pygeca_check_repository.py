#!/usr/bin/env python 


"""Reads output from lftp find -d X [1<X<3] remote_dir
   and compare it with the rinex content of a local directory
   
   Jean-Mathieu Nocquet - May 2014
   Report bug to nocquet@geoazur.unice.fr
"""
###################################################################
# MODULES IMPORT
###################################################################


import sys, os
import argparse

from glob import glob

from pyacs.lib import astrotime as AstroTime

###################################################################
# PARSE ARGUMENT LINE
###################################################################

parser = argparse.ArgumentParser()
parser.add_argument('-local_dir', action='store', required=True,type=str, dest='local_dir',help='local directory including rinex files')
parser.add_argument('-lftp_ls', action='store', required=True,type=str, dest='lftp_ls',help='file output from lftp find -d X [1<X<3] remote_dir')
parser.add_argument('-t', action='store', required=False,type=str, dest='sites_defaults',help='optional sites.defaults file')
parser.add_argument('-center', action='store', required=True,type=str, dest='center',help='data center')
parser.add_argument('--verbose', '-v', action='count',help='verbose mode')
parser.add_argument('--debug', action='count',help='debug mode')
parser.add_argument('--sd', action='store', type=int, default=None, dest='sd',help='starting doy')
parser.add_argument('--ed', action='store', type=int, default=None, dest='ed',help='end doy')
parser.add_argument('--sy', action='store', type=int, default=None, dest='sy',help='start year')
parser.add_argument('--ey', action='store', type=int, default=None, dest='ey',help='end year')


if (len(sys.argv)<2):parser.print_help()
    
args = parser.parse_args()

# verbose
if args.verbose>0:
    print("=> Verbose mode")
    verbose=True
else:
    verbose=False

# debug
if args.debug>0:
    print("=> Debug mode")
    debug=True
else:
    debug=False


###################################################################
# is rinex ?
###################################################################

def is_rinex(name,verbose=False):
    """
        check whether a file name is rinex or not
    """
    lfix=name.split('.')
    
    if len(lfix)<2:
        if verbose:print("No . (dot)")
        return(False)
    prefix=lfix[0]
    suffix=lfix[1]
    
    if len(prefix)!=8:
        if verbose:print("prefix is not 8-characters")
        return(False)
    if len(suffix)!=3:
        if verbose:print("suffix is not 3-characters")
        return(False)

    import re
    valid = re.match('[0-3]', prefix[4]) is not None
    if not valid:
        if verbose:print("4-th character of prefix is not 0-3")
        return(False)
    valid = re.match('[0-9][0-9]', prefix[5:7]) is not None
    if not valid:
        print(prefix[5:7])
        if verbose:print("5 &6-th character of prefix are not [0-9][0-9]")
        return(False)

    valid = re.match('[8,9,0,1,2][0-9][o,d]', suffix) is not None
    if not valid:
        if verbose:print("suffix is not [8,9,0,1,2][0-9][o,d]")
        return(False)
    return(True)

###################################################################
# PARSE sites.defaults file if provided
###################################################################

lsite_defaults=[]
if args.sites_defaults:
    print("=> Reading sites.defaults file")
    
       
    site_defaults=args.sites_defaults
    fs=open(site_defaults,'r')
    for line in fs:
        if line[0]=='#' or len(line) < 3:continue
        lline=line.split()
        if '_gps' in lline[0]:
            lsite_defaults.append(lline[0][0:4].lower())
    fs.close()
        
    print("=> sites.defaults OK.")
 

###i################################################################
# PARSE LFTP OUTPUT
###################################################################
lrinex_remote=[]

print("=> Reading ",args.lftp_ls)
fs = open(args.lftp_ls, 'r')

for line in fs:
    if (len(line)<2):continue
    if (line[0]=='#'):continue
    lline=line.split('/')
    file=lline[-1]
    
    if is_rinex(file):
        rinex=file[0:4]+'_'+file[4:7]+'_'+file[9:11]
        if lsite_defaults==[]:
            lrinex_remote.append(rinex)
        else:
            if file[0:4] in lsite_defaults:lrinex_remote.append(rinex)
fs.close()

###################################################################
# PARSE LOCAL DIRECTORY
###################################################################

import os

print("=> ")
def listfiles(folder):
    for root, folders, files in os.walk(folder):
        for filename in folders + files:
            yield os.path.join(root, filename)

lrinex_local=[]
print("=> Reading local rinex repository")
for line in listfiles(args.local_dir):
    if (len(line)<2):continue
    if (line[0]=='#'):continue
    lline=line.split('/')
    file=lline[-1]
    if is_rinex(file):
        rinex=file[0:4]+'_'+file[4:7]+'_'+file[9:11]
        if lsite_defaults==[]:
            lrinex_local.append(rinex)
        else:
            if file[0:4] in lsite_defaults:lrinex_local.append(rinex)

print("=> OK")
###################################################################
# COMPARE REMOTE VS LOCAL
###################################################################
if (args.ey and args.ed):
    emjd=AstroTime.dayno2mjd(args.ed,args.ey,ut=0.0)
else:
    emjd=AstroTime.dayno2mjd(0o01,2050,ut=0.0)
if (args.sy and args.sd):
    smjd=AstroTime.dayno2mjd(args.sd,args.sy,ut=0.0)
else:
    smjd=AstroTime.dayno2mjd(0o01,1980,ut=0.0)

def yr2year(yr):
    if int(yr)>80:return(str(1900+int(yr)))
    else:return(str(2000+int(yr)))
    
for rinex in lrinex_remote:
    if debug:print("- Checking rinex ",rinex)
    if rinex not in lrinex_local:
        try:      
            (site,doy,yr)=rinex.split('_')
        except:
            print("Unexpected error in (site,doy,yr)=rinex.split(\'_\'):", sys.exc_info()[0])
            print(rinex)
            continue
        try:
            mjd=AstroTime.dayno2mjd(int(doy),int(yr2year(int(yr))),ut=0.0) 
        except:
            print("Unexpected error in mjd=AstroTime.dayno2mjd(int(doy),yr2year(yr),ut=0.0):", sys.exc_info()[0])
            print(rinex)
            continue
        if (mjd>=smjd and mjd<=emjd):
                print("Get_rinex -sd ",doy," -sy ",yr2year(yr),' -ey ',yr2year(yr),' -ed ',doy,' -l ',site,' -c ',args.center,' -d ',args.local_dir)
        else:
                if debug:print("- Rinex already not in the given period")
    else:
        if debug:print("- Rinex already in lrinex_remote")
