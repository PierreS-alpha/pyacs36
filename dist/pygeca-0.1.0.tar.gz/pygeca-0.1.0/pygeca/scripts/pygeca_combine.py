#!/usr/bin/env python

"""Combine hfiles in a directory
   and produces reduced sinex files
"""
###################################################################
# MODULES IMPORT
###################################################################


import sys, os
sys.path.append(os.environ['PYACS_DIR'])
import argparse
import subprocess
import gzip
import shutil

from glob import glob

from pyacs.lib import pygamit_module
from pyacs.lib import astrotime as AstroTime

###################################################################
# PARSE ARGUMENT LINE
###################################################################

prog_info="Combine hfile in a given directory"
prog_epilog="J.-M. Nocquet (Geoazur-CNRS/IRD) - May 2012"

parser = argparse.ArgumentParser()
parser.add_argument('--dir_conf', required=True, action='store', type=str, dest='dir_conf',help='directory including configuration files')
parser.add_argument('--sd', action='store', type=int, dest='start_doy',help='starting doy')
parser.add_argument('--ed', action='store', type=int, dest='end_doy',help='end doy')
parser.add_argument('--ld', action='append', type=int, dest='list_doy',help='list of doy to be processed', default=[])
parser.add_argument('--year', required=True, action='store', type=int, dest='year',help='year')
parser.add_argument('--experiment', required=True, action='store', type=str, dest='expt',help='experiment name')

if (len(sys.argv)<2):parser.print_help()
    
args = parser.parse_args()

if not ((args.start_doy and args.end_doy) or args.list_doy):
    print("=> Either ld or (sd and ed) should be provided")
    parser.print_help()
    sys.exit()
if args.start_doy and args.end_doy:
    smjd=AstroTime.dayno2mjd(args.start_doy, args.year, ut=0.0)
    emjd=AstroTime.dayno2mjd(args.end_doy, args.year, ut=0.0)
    for mjd in range(int(smjd),int(emjd)+1):
        (doy,year,ut)=AstroTime.mjd2dayno(mjd)
        args.list_doy.append(doy)

process_defaults=args.dir_conf+'/process.defaults'
print(("=> Reading %s \n" % process_defaults))
ldir_rinex=[]
fs=open(process_defaults,'r')
for line in fs:
    if line[0]=='#' or len(line) < 3:continue
    lline=line.split()
    if 'rnxfnd' in lline[1]:ldir_rinex.append(lline[-1].replace('"',''))
    if 'aprf' in lline[1]:aprf=lline[-1]
fs.close()

###################################################################
# LOOP ON LDOY
###################################################################

for doy in args.list_doy:
    syear=str(args.year)
    syr=syear[-2:]
    sdoy="%03d" % doy

    log_suffix=args.expt+'_'+syear+'_'+sdoy
    print("=> Processing doy:",sdoy," year:",syear)
    
    log_pygeca='combine_'+log_suffix

    ###################################################################
    # CREATES PROCESSING DIRECTORY
    ###################################################################
    
    
    proc_dir= "%s_%s_%s_%s" % (os.environ['USER'],args.expt,syear,sdoy)
    
    if not os.path.isdir(proc_dir):
        print("=> ",proc_dir, "missing; skipping")
        continue
    
    print("=> cd to proc_dir ",proc_dir)
    os.chdir(proc_dir)
    flog=open(log_pygeca,'w')
    flog.write("=> Processing doy: %s year %s: \n" %(sdoy,syear))

    # list the rinex files
    lrinex=[]
    for rinex_dir in ldir_rinex:
        lrinex+=glob(rinex_dir+'/'+syear+'/'+sdoy+'/*')

    nrinex=0
    lavailable_site=[]

    flog.write("=> Reading rinex directories\n")
    
    for rinex in lrinex:
        rinex_basename=rinex.split('/')[-1]
        lavailable_site.append(rinex_basename[0:4].lower())
                
    print("=> Found ",nrinex," rinex files in directories")
    flog.write("=> Found %d rinex files in directories\n" % (nrinex))
 

    lfile = 'l'+args.expt+syr[-1]+'.'+sdoy
    path_aprf=args.dir_conf+'/'+aprf
    flog.write("=> Using pygamit_module.make_apr_doy to build apr from %s\n" % path_aprf)
    pygamit_module.make_apr_doy(path_aprf,lfile, lavailable_site, doy, args.year)


    ################################################################################
    # NOW DOING COMBINATION 
    ################################################################################
        
    cmd='uncompress -v h*'
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)

    lh=glob('hsu*')
    if len(lh)==0:continue

    # first convert the hfiles -> glx

    cmd='htoglb . \'\' hsu*'
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)
    
    lglr=glob('*glr')
    for ffile in lglr:os.remove(ffile)
    
    # creates the gdl file
    flog.write("=> Creating lgdl file\n")
    lglx=glob('*.glx')
    f_lgdl=open('lgdl','w')
    f_lgdl.write("%s\n" % lglx.pop())
    for ffile in lglx:f_lgdl.write("%s +\n" % ffile)
    
    f_lgdl.close()
    
    # creates the globk cmd file
    flog.write("=> Creating globk_comb.cmd\n")
    
    fglobk=open('globk_comb.cmd','w')
    
    fglobk.write(" apr_file tables/%s\n" % lfile)    
    fglobk.write(' apr_neu all 10 10 10 0 0 0\n')    
    fglobk.write(' apr_wob 10 10 0 0\n')    
    fglobk.write(' apr_ut1 10  0\n')
    GLX='H'+args.expt+'_'+syear+sdoy+'.GLX'    
    fglobk.write(" out_glb %s\n" % GLX)    
    fglobk.close()    
    
    # now runs GLOBK  

    suffix=args.expt+'_'+syear+'_'+sdoy
    cmd='globk 6 PRT.'+suffix+' LOG.'+suffix+' lgdl globk_comb.cmd'
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)

    # now converts to sinex  
    sinex='H'+args.expt+'_'+syear+sdoy+'.snx'
    cmd='glbtosnx . \'\' '+GLX+' '+sinex
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)
    

    flog.write("=> Saving netsel.out file\n")
    if os.path.isfile('tables/netsel.out'):shutil.copy('tables/netsel.out','netsel.out')
    llog=glob('tables/log/*')
    for log in llog:
        basename_log=log.split('/')[-1]
        shutil.copy(log,basename_log)
    
    cmd='rm -Rf tables'
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)

    flog.write("=> Compressing hfiles\n")
    
    lhfiles=glob('h*')
    for hfile in lhfiles:
        if os.path.isfile(hfile):
            f_in = open(hfile, 'rb')
            f_out = gzip.open(hfile+'.gz', 'wb')
            f_out.writelines(f_in)
            f_out.close()
            f_in.close()
            os.remove(hfile)

    # we reduce sinex to save space

    cmd='ls *.snx > lsinex'
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)

    cmd='pyacs_reduce_sinex.py -l lsinex -o . -e ss'
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)

    cmd='rm -f *.snx'
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)
    
    # now we run a simple helmert transformation

    cmd='ls *.ss > lsinex'
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)
    
    cmd='touch pyacs_conf.dat'
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)

    cmd='pyacs_make_time_series.py  --lsinex lsinex --ref_sinex /projet/gps/geodesy/igs/IGS11P18.snx.ss          --discontinuity /projet/gps/geodesy/igs/soln.snx --conf_file pyacs_conf.dat --experiment helmert'
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)

    # we update the apr
    
    cmd='pygamit_update_apr.py -t '+path_aprf+ ' -d helmert/stat/pyacs.apr -s 0.3'    
    print("=> Running ",cmd)
    flog.write("=> Running %s\n" % cmd)
    subprocess.getstatusoutput(cmd)

    flog.write("=> End of combination\n")
    
    flog.close()
    
    os.chdir('..')
