#!/usr/bin/env python 


"""Automated GAMIT processing using the cluster at Geoazur
   Check that all sites of an experiment have been processed
   by comparing a list of sinex files with the rinex files
   found in the directories listed in the process.defaults
   
   Jean-Mathieu Nocquet - August 2012 - Updated from geca in perl
   Report bug to nocquet@geoazur.unice.fr
"""
###################################################################
# MODULES IMPORT
###################################################################

import sys, os
import argparse

from glob import glob

from pyacs.lib import astrotime as AstroTime

min_rinex_size = 50 # 50 kb min to be reprocessed

###################################################################
# PARSE ARGUMENT LINE
###################################################################

parser = argparse.ArgumentParser()
parser.add_argument('-dir_conf', action='store', required=True,type=str, dest='dir_conf',help='directory including configuration files')
parser.add_argument('-lsinex', action='store', required=True,type=str, dest='lsinex',help='file including the list of sinex files')
parser.add_argument('-type', action='store', type=str, dest='type',default='best',help='analysis type: best or rapid')
parser.add_argument('--verbose', '-v', action='count',default=0,help='verbose mode')
parser.add_argument('--debug', '-d', action='count',default=0,help='debug mode')
parser.add_argument('--all', action='count',default=0,help='check for all available rinex, otherwise only for sites listed in sites.defaults (default)')


if (len(sys.argv)<2):parser.print_help()
    
args = parser.parse_args()

# verbose
if args.verbose>0:
    print("=> Verbose mode")
    verbose=True
else:
    verbose=False

# debug
if args.debug>0:
    print("=> Debug mode")
    debug=True
else:
    debug=False


# all
if args.all>0:
    print("=> All rinex available will be checked")
    all=True
else:
    all=False
    print("=> Only sites in sites.defaults will be checked")


###################################################################
# READS SITE.DEFAULTS
###################################################################

print("=> Reading sites.defaults file")

lsite=[]

   
site_defaults=args.dir_conf+'/sites.defaults'
try:
    fs=open(site_defaults,'r',encoding="latin-1")
except:
    print("!!! Could not open ", site_defaults,'. Exiting...')
    sys.exit()
    
for line in fs:
    if line[0]=='#' or len(line) < 3:continue
    lline=line.split()
    if '_gps' in lline[0] :
        lsite.append(lline[0][0:4].lower())
        experiment=lline[1][0:4]
fs.close()
    
if verbose:print("=> sites.defaults OK.")


###################################################################
# READS process.defaults
###################################################################

    # Get the directories from process.defaults
    
process_defaults=args.dir_conf+'/process.defaults'


ldir_rinex=[]
try:
    fs=open(process_defaults,'r',encoding="latin-1")
except:
    print("!!! Could not open ",process_defaults)
    sys.exit()

for line in fs:
    if line[0]=='#' or len(line) < 3:continue
    lline=line.split()
    if 'rnxfnd' in lline[1]:ldir_rinex.append(lline[-1].replace('"',''))
    if 'aprf' in lline[1]:aprf=args.dir_conf+'/'+lline[-1]
fs.close()


###################################################################
# READS AVAILABLE SINEX
###################################################################

from pyacs.sol import sinex as Sinex

H_sinex={}
H_sinex_name={}

if verbose:print("=> Reading ",args.lsinex)

flsinex=open(args.lsinex,encoding="latin-1")

for sinex_name in flsinex:
    if verbose:print("  => Reading content of ",sinex_name)
    sinex=Sinex.SSinex(sinex_name.rstrip())
    ll=sinex_name.split('/')
    sinex_basename=ll[-1].rstrip()
#    sinex.read()
    sinex.read_section_estimate()
    epoch=sinex.epoch
    (doy,ut)=AstroTime.decyear2dayno(epoch)
    sdoy="%03d" % doy
    syear=str(int(epoch))
    H_sinex_name[(sdoy,syear)]=sinex_basename
    lsite_sinex=sinex.lcode()
    for site in lsite_sinex:
        if (sdoy,syear) in H_sinex:
            H_sinex[(sdoy,syear)].append(site.lower())
        else:
            H_sinex[(sdoy,syear)]=[site.lower()]
    if debug:print((sdoy,syear),H_sinex[(sdoy,syear)])

if verbose:print(H_sinex)

###################################################################
# READS AVAILABLE RINEX
###################################################################

H_rinex={}
H_rinex_size={}
H_rinex_path={}

for (sdoy,syear) in sorted(H_sinex.keys()):
    #syear=str(year)
    syr=syear[-2:]
    #sdoy="%03d" % doy

    #log_suffix=args.expt+'_'+syear+'_'+sdoy

    if verbose:print("=> Reading rinex files for doy:",sdoy," year:",syear)

    # list the rinex files
    lrinex=[]
    for rinex_dir in ldir_rinex:
        lrinex+=glob(rinex_dir+'/'+syear+'/'+sdoy+'/*')
    
    # link the rinex files if site code is in sites.defaults
    
    nrinex=0
    
    for rinex in lrinex:
        print(rinex)
        if not os.path.isfile(rinex):continue
        rinex_basename=rinex.split('/')[-1]
        site_rinex=rinex_basename[0:4].lower()
        doy_rinex=rinex_basename[4:7]
       
        size=os.path.getsize(rinex)
        H_rinex_size[(doy_rinex,syear,site_rinex)]=size/1024
        H_rinex_path[(doy_rinex,syear,site_rinex)]=rinex
        if (sdoy,syear) in H_rinex:
            print(rinex,site_rinex)
            H_rinex[(doy_rinex,syear)].append(site_rinex)
        else:
            H_rinex[(doy_rinex,syear)]=[site_rinex]
            
        if verbose:print((sdoy,syear),H_rinex[(sdoy,syear)])
        #print os.path.getsize(rinex),min_rinex_size
#            if os.path.getsize(rinex)/1024. <min_rinex_size:print "=> WARNING: small rinex file ",rinex


if verbose:print("=> End of rinex listing.")
if debug:print(H_rinex)


###################################################################
# CROSS SINEX/RINEX INFO
###################################################################

for (sdoy,syear) in sorted(H_sinex.keys()):
    lsite_redo=[]
    if verbose:print("=> Checking doy : ",sdoy,syear)        
    lsite_sinex=H_sinex[(sdoy,syear)]
    lsite_rinex=list(set(H_rinex[(sdoy,syear)]))
    sinex_basename=H_sinex_name[(sdoy,syear)]
    for site in sorted(lsite_rinex):
        if all:
            if site not in lsite_sinex:
                print(("=> !!! %s not found in %s (%3dK) from %s" % (site,sinex_basename,H_rinex_size[(sdoy,syear,site)],H_rinex_path[(sdoy,syear,site)])))
                lsite_redo.append(site)
        else:
            if site not in lsite_sinex and site in lsite:
                print(("=> !!! %s not found in %s (%3dK) from %s" % (site,sinex_basename,H_rinex_size[(sdoy,syear,site)],H_rinex_path[(sdoy,syear,site)])))
                if H_rinex_size[(sdoy,syear,site)] > min_rinex_size:lsite_redo.append(site)

    string_lsite=' --site '+' --site '.join(lsite_redo)
    if lsite_redo != []:
#        print("pygeca_redo.py --experiment %s --dir_conf %s --year %s --type best --ld %s %s" % (experiment,args.dir_conf,syear,sdoy,string_lsite))
        print(("pygeca_redo_make_job.py --walltime 6 --queue QDR/DDR/NONE --experiment %s --dir_conf %s --year %s --type %s --ld %s %s" % (experiment,args.dir_conf,syear,args.type,sdoy,string_lsite)))
    
    
