from setuptools import setup

###############################################################################
# VERSION HISTORY
# 0.01.0 on 20190401 : pygeca separated from pyacs
###############################################################################


setup(name='pygeca',
      version='0.01.0',
      description='PYGECA: PYACS GAMIT CLUSTER PROCESSING',
      long_description='PYGECA: PYACS GAMIT CLUSTER PROCESSING.',
 
      classifiers=[
        'Development Status :: 3 - Alpha',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3.6',
        'Topic :: Geodesy :: Geophysics',
      ],
      keywords='geodesy GPS GNSS GAMIT GLOBK HPC',
      url='',
      author='Jean-Mathieu Nocquet (Geoazur, IRD, CNRS, OCA, Cote d Azur University, France)',
      author_email='nocquet@geoazur.unice.fr',
      license='NA',
      packages=['pygeca'],
       scripts=[\
#                # PYGECA
                'pygeca/scripts/pygeca_subnetworks.py',     \
                'pygeca/scripts/pygeca_resubmit.py',        \
                'pygeca/scripts/pygeca_make_job.py',        \
                'pygeca/scripts/pygeca_redo_make_job.py',   \
                'pygeca/scripts/pygeca_redo.py',            \
                'pygeca/scripts/pygeca_check_gamit.py',     \
                'pygeca/scripts/pygeca_check_sinex.py',     \
                'pygeca/scripts/pygeca_check_repository.py',\
                'pygeca/scripts/pygeca_combine.py',         \
                'pygeca/scripts/pygeca_find_rinex.py',      \
                'pygeca/scripts/pygeca_sinex2apr.py',       \
                'pygeca/scripts/pygeca_soln2eq_rename.py',  \
                ],
      install_requires=['pyacs>=0.67.0'],
      zip_safe=False,

      test_suite='nose.collector',
      tests_require=['nose'],
)
