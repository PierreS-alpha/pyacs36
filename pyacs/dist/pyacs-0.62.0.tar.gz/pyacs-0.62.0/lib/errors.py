class Error(Exception):
    """Base class for exceptions in module PYACS"""
    pass

class OptionError(Exception):
    """Exception raised for an option not allowed."""
    pass
